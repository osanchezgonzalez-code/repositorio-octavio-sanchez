# s14 mediaqueries-octavio-sanchez

A Pen created on CodePen.

Original URL: [https://codepen.io/OCTAVIO-SANCHEZGONZALEZ/pen/RNrVzKE](https://codepen.io/OCTAVIO-SANCHEZGONZALEZ/pen/RNrVzKE).

